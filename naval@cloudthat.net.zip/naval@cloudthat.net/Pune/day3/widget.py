# Databricks notebook source
dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("enviroment"," ")

# COMMAND ----------

dbutils.widgets.get("enviroment")

# COMMAND ----------

