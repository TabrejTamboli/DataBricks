# Databricks notebook source
input_path="dbfs:/mnt/cloudthats3/raw/finance.json"