# Databricks notebook source
input_raw_files="dbfs:/mnt/cloudthats3/formula1_raw"
output_path="dbfs:/mnt/cloudthats3/output_formula1/"

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

