# Databricks notebook source
# MAGIC %sql
# MAGIC select * from climate25_temp

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.climate25_global

# COMMAND ----------

