# Databricks notebook source
# MAGIC %sql
# MAGIC create catalog dev

# COMMAND ----------

