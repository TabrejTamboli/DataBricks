# Databricks notebook source
print("Hello World")

# COMMAND ----------

print("Hello DB")

# COMMAND ----------

# DBTITLE 1,DATABRICKSS
print("This is Sandeep")

# COMMAND ----------

# MAGIC %sql select current_date()

# COMMAND ----------

print("This is Vijay")

# COMMAND ----------

print("Hello World - VIshal")

# COMMAND ----------

print("Yello")

# COMMAND ----------

Print("Tabrej")

# COMMAND ----------

print('This Is Amit')

# COMMAND ----------

print("This is Meghna")

# COMMAND ----------

Print("Hello MMC")

# COMMAND ----------

print("Pandurang here")

# COMMAND ----------

print("Hello from FK")