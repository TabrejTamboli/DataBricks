# Databricks notebook source
# MAGIC %md
# MAGIC ## DBDemos asset
# MAGIC
# MAGIC The notebooks available under `_/resources` are technical resources.
# MAGIC
# MAGIC Do not edit these notebooks or try to run them directly. These notebooks will load data / run some setup. They are indirectly called from the main notebook (`%run ./_resources/.....`)