# Databricks notebook source
# MAGIC %fs ls dbfs:/mnt/cloudthats3/stream/input/csv_raw/finance_data/

# COMMAND ----------

input_file="dbfs:/mnt/cloudthats3/stream/input/csv_raw/finance_data/"

# COMMAND ----------

