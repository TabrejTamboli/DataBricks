-- Databricks notebook source
select * from circuit_spain

-- COMMAND ----------

select * from global_temp.circuit_turkey

-- COMMAND ----------

