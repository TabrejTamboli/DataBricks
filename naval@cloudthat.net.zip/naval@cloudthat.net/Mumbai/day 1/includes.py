# Databricks notebook source
input_path="dbfs:/mnt/cloudthats3/formula1_raw/"

# COMMAND ----------

