# Databricks notebook source
print("hello")

# COMMAND ----------

# MAGIC %sql
# MAGIC select "Hello"

# COMMAND ----------

spark

# COMMAND ----------

print('Hellloooo')

# COMMAND ----------

print("Hello from Dixit")

# COMMAND ----------

print("Madhavi")

# COMMAND ----------

print("SS")

# COMMAND ----------

print("Hello")

# COMMAND ----------

print("Hello")

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema naval

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

