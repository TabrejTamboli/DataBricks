# Databricks notebook source
df=spark.read.table("hive_metastore.naval.climate_1")

# COMMAND ----------

