# Databricks notebook source
# MAGIC %fs ls dbfs:/databricks-datasets/airlines/

# COMMAND ----------

