-- Databricks notebook source
describe detail hive_metastore.naval.climate_1

-- COMMAND ----------

describe extended hive_metastore.naval.climate_1

-- COMMAND ----------

