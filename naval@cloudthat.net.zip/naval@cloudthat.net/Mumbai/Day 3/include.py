# Databricks notebook source
input_stream="dbfs:/mnt/cloudthats3/stream/input/csv_raw/emp"
output_stream="dbfs:/mnt/cloudthats3/stream/output/"