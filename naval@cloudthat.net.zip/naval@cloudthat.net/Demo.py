# Databricks notebook source
# MAGIC %pip install dbdemos

# COMMAND ----------

import dbdemos
dbdemos.install('sql-ai-functions', catalog='main', schema='dbdemos_ai_query')

# COMMAND ----------

import dbdemos
dbdemos.install('llm-rag-chatbot', catalog='main', schema='rag_chatbot')

# COMMAND ----------

